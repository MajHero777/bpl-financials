import ServicesList from "@/components/services-list"

export default function ServicesPage() {
  return <ServicesList />
}

