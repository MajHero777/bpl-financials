import FAQList from "@/components/faq-list"

export default function FAQPage() {
  return <FAQList />
}

