import DocumentRequestForm from "@/components/document-request-form"

export default function TermsAndConditionsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Terms and Conditions</h1>
      <p className="mb-6">
        To receive a copy of our Terms and Conditions, please submit your email address below. We will send the document
        to your email shortly.
      </p>
      <div className="max-w-md">
        <DocumentRequestForm documentType="Terms and Conditions" />
      </div>
    </div>
  )
}

