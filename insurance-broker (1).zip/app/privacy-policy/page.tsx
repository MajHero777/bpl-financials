"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import DocumentRequestForm from "@/components/document-request-form"

export default function PrivacyPolicyPage() {
  const [showForm, setShowForm] = useState(false)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
      {!showForm ? (
        <div>
          <p className="mb-6">
            Our Privacy Policy is not publicly available on this page. To receive a copy of our Privacy Policy, please
            click the button below to request the document.
          </p>
          <Button onClick={() => setShowForm(true)}>Request Privacy Policy</Button>
        </div>
      ) : (
        <div>
          <p className="mb-6">
            To receive a copy of our Privacy Policy, please submit your email address below. We will send the document
            to your email shortly.
          </p>
          <div className="max-w-md">
            <DocumentRequestForm documentType="Privacy Policy" />
          </div>
        </div>
      )}
    </div>
  )
}

