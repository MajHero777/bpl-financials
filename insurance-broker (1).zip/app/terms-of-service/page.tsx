"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import DocumentRequestForm from "@/components/document-request-form"

export default function TermsOfServicePage() {
  const [showForm, setShowForm] = useState(false)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
      {!showForm ? (
        <div>
          <p className="mb-6">
            Our Terms of Service are not publicly available on this page. To receive a copy of our Terms of Service,
            please click the button below to request the document.
          </p>
          <Button onClick={() => setShowForm(true)}>Request Terms of Service</Button>
        </div>
      ) : (
        <div>
          <p className="mb-6">
            To receive a copy of our Terms of Service, please submit your email address below. We will send the document
            to your email shortly.
          </p>
          <div className="max-w-md">
            <DocumentRequestForm documentType="Terms of Service" />
          </div>
        </div>
      )}
    </div>
  )
}

