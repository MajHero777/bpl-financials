import Home from "@/components/home"

export default function Page() {
  return <Home />
}

