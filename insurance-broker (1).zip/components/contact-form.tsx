"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Phone, Mail, MapPin } from "lucide-react"
import Image from "next/image"
import { useToast } from "@/components/ui/use-toast"

export default function ContactForm() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      const response = await fetch("/api/submit-contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, email, phone, message }),
      })

      if (response.ok) {
        toast({
          title: "Message Sent Successfully",
          description: "Thank you for contacting us. We'll get back to you as soon as possible.",
          duration: 5000,
        })
        setName("")
        setEmail("")
        setPhone("")
        setMessage("")
      } else {
        throw new Error("Failed to submit contact form")
      }
    } catch (error) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: "Failed to send your message. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-12 text-foreground">Contact Us</h1>
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <p className="text-muted-foreground mb-8">
              We're here to help you with any questions you may have about our services. Feel free to reach out to us
              using the contact form or the information below.
            </p>
            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-4">
                <Phone className="text-primary" />
                <span className="text-muted-foreground">+27 69 114 6631</span>
              </div>
              <div className="flex items-center space-x-4">
                <Mail className="text-primary" />
                <span className="text-muted-foreground">info@bplfinancials.co.za</span>
              </div>
              <div className="flex items-center space-x-4">
                <MapPin className="text-primary" />
                <span className="text-muted-foreground">1 Cavendish Rd, Vincent, East London, 5247</span>
              </div>
            </div>
            <div className="relative h-[300px] rounded-xl overflow-hidden shadow-lg">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/christina-wocintechchat-com-RTJIXQNne68-unsplash.jpg-dPTjWMFvTkRNm5HaiQhZFv6O2cTU4t.jpeg"
                alt="Contact Support"
                fill
                className="object-cover image-sharp"
              />
            </div>
          </div>
          <div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="text"
                placeholder="Your Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="bg-card border-primary/20 text-foreground"
              />
              <Input
                type="email"
                placeholder="Your Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-card border-primary/20 text-foreground"
              />
              <Input
                type="tel"
                placeholder="Your Phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="bg-card border-primary/20 text-foreground"
              />
              <Textarea
                placeholder="Your Message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                className="bg-card border-primary/20 text-foreground"
              />
              <Button
                type="submit"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}

