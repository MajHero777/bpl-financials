import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Toaster } from "@/components/ui/toaster"
import QuoteForm from "./quote-form"

export default function Header() {
  return (
    <header className="bg-background shadow-sm border-b border-primary/20">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/2024-09-24.jpg-X1TuCoqvdimQYvSq7btkD2V149qEoR.jpeg"
            alt="BPL Financials Logo"
            width={120}
            height={40}
            className="object-contain"
          />
        </Link>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Link href="/" className="text-sm font-medium text-foreground hover:text-muted-foreground">
                Home
              </Link>
            </li>
            <li>
              <Link href="/services" className="text-sm font-medium text-foreground hover:text-muted-foreground">
                Services
              </Link>
            </li>
            <li>
              <Link href="/faq" className="text-sm font-medium text-foreground hover:text-muted-foreground">
                FAQ
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-sm font-medium text-foreground hover:text-muted-foreground">
                Contact
              </Link>
            </li>
          </ul>
        </nav>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Get a Quote</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Request a Quote</DialogTitle>
              <DialogDescription>
                Fill in your details and we'll get back to you with a personalized quote.
              </DialogDescription>
            </DialogHeader>
            <QuoteForm />
          </DialogContent>
        </Dialog>
      </div>
      <Toaster />
    </header>
  )
}

