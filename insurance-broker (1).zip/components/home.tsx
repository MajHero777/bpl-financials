import { Button } from "@/components/ui/button"
import { ArrowRight, Shield, TrendingUp, Users } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function Home() {
  return (
    <div className="bg-background">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-center md:text-left">
              <h1 className="text-4xl font-bold mb-6 text-foreground">Welcome to BPL Financials</h1>
              <p className="text-xl mb-8 text-muted-foreground">
                Your trusted partner in financial planning and insurance solutions.
              </p>
              <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/services">Explore Our Services</Link>
              </Button>
            </div>
            <div className="relative h-[400px] rounded-xl overflow-hidden shadow-xl">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/african-man-guy-black-suit-people-with-tablet-girl-white-blouse.jpg-GOifMX5gX9KJmajIG3DezbIaZauYfF.jpeg"
                alt="Professional Financial Advisors"
                fill
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Why Choose BPL Financials?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-12">
            <div className="relative h-[500px] rounded-xl overflow-hidden shadow-lg">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/group-afro-americans-working-together.jpg-O7lEwI7JW6BLd5xPYfwjt7ZEmQwWr4.jpeg"
                alt="Professional Team Collaboration"
                fill
                className="object-cover"
              />
            </div>
            <div className="grid gap-8">
              <div className="text-left">
                <Shield className="w-12 h-12 text-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2 text-foreground">Comprehensive Protection</h3>
                <p className="text-muted-foreground">
                  We offer a wide range of insurance products to safeguard what matters most to you.
                </p>
              </div>
              <div className="text-left">
                <TrendingUp className="w-12 h-12 text-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2 text-foreground">Expert Financial Advice</h3>
                <p className="text-muted-foreground">
                  Our team of experienced advisors will help you make informed financial decisions.
                </p>
              </div>
              <div className="text-left">
                <Users className="w-12 h-12 text-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2 text-foreground">Personalized Service</h3>
                <p className="text-muted-foreground">We tailor our solutions to meet your unique needs and goals.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Keep the rest of the sections unchanged */}
      <section className="py-20 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-8 text-foreground">Our Digital Solutions</h2>
              <div className="relative h-[400px] rounded-xl overflow-hidden shadow-lg mb-8">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/christina-wocintechchat-com-L85a1k-XqH8-unsplash.jpg-lGzArcKoT4sJgEQte2SjqHASu7Hd92.jpeg"
                  alt="Modern Financial Technology"
                  fill
                  className="object-cover image-sharp"
                />
              </div>
              <p className="text-muted-foreground">
                We leverage cutting-edge technology to provide you with the best financial services and protection for
                your future.
              </p>
            </div>
            <div className="grid gap-6">
              {["Insurance", "Financial Planning", "Investment Advice", "Retirement Planning"].map((service, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-2 text-foreground">{service}</h3>
                  <p className="text-muted-foreground mb-4">Tailored solutions to protect and grow your assets.</p>
                  <Link href="/services" className="text-foreground hover:text-foreground/80 inline-flex items-center">
                    Learn More <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

