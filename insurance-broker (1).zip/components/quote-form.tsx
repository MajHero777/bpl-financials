"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

export default function QuoteForm() {
  const [name, setName] = useState("")
  const [surname, setSurname] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [description, setDescription] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      const response = await fetch("/api/submit-quote", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, surname, email, phone, description }),
      })

      if (response.ok) {
        toast({
          title: "Quote Request Submitted Successfully",
          description:
            "Thank you for your interest. Your quote information has been sent. You can expect to receive a detailed quote within 1-3 business days.",
          duration: 10000, // Display for 10 seconds
        })
        setName("")
        setSurname("")
        setEmail("")
        setPhone("")
        setDescription("")
      } else {
        throw new Error("Failed to submit quote request")
      }
    } catch (error) {
      console.error("Error:", error)
      toast({
        title: "Error",
        description: "Failed to submit quote request. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Name</Label>
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="bg-card border-primary/20 text-foreground"
        />
      </div>
      <div>
        <Label htmlFor="surname">Surname</Label>
        <Input
          id="surname"
          value={surname}
          onChange={(e) => setSurname(e.target.value)}
          required
          className="bg-card border-primary/20 text-foreground"
        />
      </div>
      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="bg-card border-primary/20 text-foreground"
        />
      </div>
      <div>
        <Label htmlFor="phone">Phone</Label>
        <Input
          id="phone"
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
          className="bg-card border-primary/20 text-foreground"
        />
      </div>
      <div>
        <Label htmlFor="description">Which service would you like a quote for?</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
          placeholder="Please describe which service you're interested in (e.g., Life Insurance, Funeral Cover, Income Protection, etc.)"
          className="bg-card border-primary/20 text-foreground min-h-[100px]"
        />
      </div>
      <Button
        type="submit"
        className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
        disabled={isSubmitting}
      >
        {isSubmitting ? "Sending..." : "Get Quote"}
      </Button>
    </form>
  )
}

